def warning( str ):
    """
    print warning message
    """

    from colors import red

    print(red("[PYEQ WARNING] %s" % (str)))

