def warning( str ):
    """
    print warning message
    """

    from colors import red

    print(red("[PYACS WARNING] %s" % (str)))

